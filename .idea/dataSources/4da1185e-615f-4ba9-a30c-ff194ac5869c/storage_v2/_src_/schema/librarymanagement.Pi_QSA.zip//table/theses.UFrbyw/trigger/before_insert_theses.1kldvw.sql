create definer = root@localhost trigger before_insert_theses
    before insert
    on theses
    for each row
BEGIN
    -- Thêm bản ghi mới vào bảng Documents
    INSERT INTO Documents (title, description, language, publication_year)
    VALUES (NEW.title, NEW.description, NEW.language, NEW.publication_year);

    -- Lấy ID của bản ghi vừa tạo trong bảng Documents
    SET NEW.id = LAST_INSERT_ID(); -- Đặt id của Theses bằng id vừa tạo của Documents
END;

